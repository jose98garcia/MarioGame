#!/bin/bash
set -e -x
javac Main.java Json.java
